import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class AktoriusExport {
	public static void main(String[] args) {
		try {
			Connection myConn = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/12-26", "root", "");
			Statement myStmt = myConn.createStatement();
			ResultSet myRs = myStmt.executeQuery("select * from aktorius");
			
			PrintWriter writer = new PrintWriter("AktoriuInsertValues.txt", "UTF-8");
			
			while (myRs.next()) {
				writer.println("insert into Aktorius values("
					+ myRs.getString("AktoriausId") + ", "
						 + myRs.getString("ZmogausId") + ");");
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
