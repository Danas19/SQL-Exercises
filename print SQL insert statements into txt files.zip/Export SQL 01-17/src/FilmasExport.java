import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class FilmasExport {
	public static void main(String[] args) {
		try {
			Connection myConn = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/12-26", "root", "");
			Statement myStmt = myConn.createStatement();
			ResultSet myRs = myStmt.executeQuery("select * from filmas");
			
			PrintWriter writer = new PrintWriter("FilmuInsertValues.txt", "UTF-8");
			
			while (myRs.next()) {
				writer.println("insert into Filmas values("
					+ myRs.getInt("FilmoId") + ", '" + myRs.getString("Pavadinimas") + "', "
						+ myRs.getInt("PastatymoMetai") + ", " + myRs.getInt("Trukme") + ", "
								+ myRs.getInt("KalbosId") + ", '" + myRs.getString("Premjera")
										+ "', " + myRs.getString("SukurimoValstybesId") + ");");
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
