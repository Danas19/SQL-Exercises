import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Kritikas {
	public static void main(String[] args) {
		try {
			Connection myConn = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/12-26", "root", "");
			Statement myStmt = myConn.createStatement();
			ResultSet myRs = myStmt.executeQuery("select * from kritikas");
			
			PrintWriter writer = new PrintWriter("KritikasInsertValues.txt", "UTF-8");
			
			while (myRs.next()) {
				writer.println("insert into kritikas values("
					+ myRs.getString("KritikoId") + ", "
						 + myRs.getString("ZmogausId") + ");");
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Viskas.");
	}
}
