import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Valstybe {
	public static void main(String[] args) {
		try {
			Connection myConn = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/12-26", "root", "");
			Statement myStmt = myConn.createStatement();
			ResultSet myRs = myStmt.executeQuery("select * from Valstybe");
			
			PrintWriter writer = new PrintWriter("ValstybeInsertValues.txt", "UTF-8");
			
			while (myRs.next()) {
				writer.println("insert into Valstybe values("
					+ myRs.getString("ValstybesId") + ", '"
						 + myRs.getString("Valstybe") + "');");
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Viskas.");
	}
}
