import java.io.PrintWriter;

public class Kalba {
	public static void main(String[] args) {
		try {
			
			PrintWriter writer = new PrintWriter("KalbaInsertValues.txt", "UTF-8");
			
			writer.println("insert into kalba values(1, \"English\");\r\n" + 
					"	insert into kalba values(2, \"Japanese\");");
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Viskas.");
	}
}
