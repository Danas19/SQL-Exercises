import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Zanras {
	public static void main(String[] args) {
		try {
			Connection myConn = DriverManager
				.getConnection("jdbc:mysql://localhost:3306/12-26", "root", "");
			Statement myStmt = myConn.createStatement();
			ResultSet myRs = myStmt.executeQuery("select * from Zanras");
			
			PrintWriter writer = new PrintWriter("ZanrasInsertValues.txt", "UTF-8");
			
			while (myRs.next()) {
				writer.println("insert into Zanras values("
					+ myRs.getString("ZanroId") + ", '"
						 + myRs.getString("Pavadinimas") + "');");
			}
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Viskas.");
	}
}
